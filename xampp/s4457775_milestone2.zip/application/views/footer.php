<footer>
	<div class="d-flex justify-content-around mt-3">
		<div class="d-flex flex-column align-items-center">
			<h6 style="color: white;">About Us</h6>
			<a class="footerLink" href="#"><small>About our company</small></a>
			<a class="footerLink" href="#"><small>Contact us</small></a>
		</div>
		<div class="d-flex flex-column align-items-center">
			<h6 style="color: white;">Tips &#38; Help</h6>
			<a class="footerLink" href="#"><small>FAQs</small></a>
		</div>
	</div>
	<div class="copyright d-flex justify-content-center">
		<p><small>Copyright by UniversalBuy</small></p>
	</div>
</footer>

