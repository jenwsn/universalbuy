
<body class="signinBody">
<div id="page-container">

		<div class="d-flex flex-column align-items-center mt-3">
			<h1 class="display-4">Post a new item</h1>
			<h2 class="display-5">Write information about the item</h2>

			<!-- Create a form -->
			<?php echo validation_errors(); ?>
			<?php echo form_open_multipart('post/do_upload'); ?>
			<!-- <form method="POST" action="registerfunc.php" class="d-flex flex-column align-items-center mt-2"> -->
			<div class="form-group col-xs-5 col-lg-10 col-centered mt-3" style="width: 150%;">
				<input id="name" type="text" name="name" placeholder="Title of post" class="form-control" required>
			</div>
			<div class="form-group col-xs-5 col-lg-10 col-centered mt-3" style="width: 150%;">
				<input name="price" id="price" type="text" placeholder="Cost of item" class="form-control" required>
			</div>
			<div class="form-group col-xs-5 col-lg-10 col-centered mt-3" style="width: 150%;">
				<input id="description" type="text" name="description" placeholder="Description" class="form-control" required>
			</div>
<!--			--><?php //echo form_upload(['name'=>'userfile', 'value'=>'Save']); ?>
<!--			<div class="text-center mt-3">-->
			<input type="file" name="userfile" size="20" />
			<button id="submit-button" type="submit" value="upload"class="btn btn-primary text-center">Post</button>
			</div>
			<?php
			echo form_close();
			?>

		</div>
	</div>
</body>
