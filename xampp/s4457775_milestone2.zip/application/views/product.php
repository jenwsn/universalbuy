<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
		  integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css"
		  href="<?php echo base_url();?>css/style.css">

	<title>Seconds</title>

	<div class="d-flex flex-column align-items-center mt-3">
		<div class="card mb-3" style="width:70%;">

			<?php
			//reconnect to database
			$this->load->database();

			//load array helper
			$this->load->helper('array');

			//retrieve item picture
			$pic_sql = "SELECT path FROM product WHERE productid = ?";
			$pic_query = $this->db->query($pic_sql, array($productid));
			$picture = $pic_query->row_array();

			if($picture != null){
				echo "<img src='";
				echo base_url();
				echo "images/";
				echo $picture['path'];
				echo "' class='card-img-top' alt='sampleItem' style='width:30%; align-self: center;'>";
			}

			?>
			<div class="card-header">
				<div class="d-flex d-flex justify-content-between">
					<h2 class="card-title"><?php echo $name?></h2>
					<h2>$<?php echo $price?></h2>
				</div>
			</div>
			<div class="card-body">
				<p class="card-text"><?php echo $description?></p>
			</div>
			<div class="text-center mt-3">
				<button id="submit-button" type="submit" class="btn btn-primary text-center"
						onclick="window.location='<?php echo site_url("Product/add_cart/"."$productid");?>'">Add to Cart</button>
			</div>
			<?php echo $this->session->flashdata('login_error')?>
			<br><br>
			<div class="container">
				<form method="POST" id="comment_form">
					<div class="form-group">
						<input type="text" name="comment_name" id="comment_name" class="form-control" placeholder="Enter Name" />
					</div>
					<div class="form-group">
						<textarea name="comment_content" id="comment_content" class="form-control" placeholder="Enter Comment" rows="5"></textarea>
					</div>
					<div class="form-group">
						<input type="hidden" name="comment_id" id="comment_id" value="0" />
						<input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
					</div>
				</form>
				<span id="comment_message"></span>
				<br />
				<div id="display_comment"></div>
			</div>
		</div>
	</div>



