<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<div class="d-flex flex-column align-items-center mt-5 mb-5">

	<?php
	//URL helper
	$this->load->helper('url');

	if(isset($_SESSION['is_signed_in'])){
		echo "<h1>Welcome, " . $_SESSION['username']. ". </h1>";
	}else{
		echo "<h1>Todays Top Picks</h1>";
	}
	?>
</div>

<div class="bd-example">
	<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
		<ol class="carousel-indicators">
			<li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
			<li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
			<li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
		</ol>
		<div class="carousel-inner">
			<div class="carousel-item active">
				<img src="images/banner3.jpeg" class="d-block w-100" alt="..." height="60%" width="100%">
				<div class="carousel-caption d-none d-md-block">
					<h5>First slide label</h5>
					<p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
				</div>
			</div>
			<div class="carousel-item">
				<img src="images/banner2.jpeg" class="d-block w-100" alt="..." height="60%" width="100%">
				<div class="carousel-caption d-none d-md-block">
					<h5>Second slide label</h5>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
				</div>
			</div>
			<div class="carousel-item">
				<img src="images/banner1.jpeg" class="d-block w-100" alt="..." height="60%" width="100%">
				<div class="carousel-caption d-none d-md-block">
					<h5>Third slide label</h5>
					<p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
				</div>
			</div>
		</div>
		<a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
	</div>

<div class="d-flex flex-column align-items-center mt-5 mb-5">
	<h1>Recommended for you</h1>
</div>
<div class="card-columns ml-5" id="recommendationCardDeck">

	<?php
	//reconnect to the database
	$this->load->database();

	//list of all items in the user's wish list
	$wishlist_items = array();

	//retrieve all the item information here
	$sql = "SELECT * FROM product";
	$query = $this->db->query($sql);


	foreach($query->result_array() as $row) {
		echo "<div class='card' style='width: 24rem;'>";
		//retrieve item picture
		$pic_sql = "SELECT path FROM product WHERE productid = ?";
		$pic_query = $this->db->query($pic_sql, array($row['productid']));
		$picture = $pic_query->row_array();

		if($picture['path'] != null){
			$data = 'images/'.$picture['path'];
			echo "<img src=$data class='card-img-top' alt='test'>";

//			echo '"';?><!--<img src=--><?php //echo base_url().""."$data.""class='card-img-top' alt='test'>";
			echo "<a id='cardLinks' href='";
			echo base_url('Product/index/');
			echo $row['productid'];
			echo "'>";
		}
		echo "<div class='card-body'> <div class='d-flex d-flex justify-content-between'>";
		echo "<h5 class='card-title'>";
		echo $row['name'];
		echo "</h5>";

		echo "<p class='card-text'><b>";
		echo $row['price'];
		echo "</b></p>";
		echo "</div>";

		echo "<a id='cardLinks' href='";
		echo site_url('like/index');
		echo "/";
		echo $row['productid'];
		echo "/entry";
		echo "'>";

		echo "<div class='heart'>";
		echo "<div class='card-footer like'>";
		echo "<p style='display: inline-block;'>";
		echo $row['likes'];
		echo "</p>";
		echo "<img src='";
		echo base_url();
		echo "images/heart_empty.png' id='heart_empty'alt='empty_heart'>";
		echo "</div>";
		echo "<div class='card-footer unlike'>";
		echo "<p style='display: inline-block;'>";
		echo $row['likes'];
		echo "</p>";
		echo "<img src='";
		echo base_url();
		echo "images/heart_fill.png' id='heart_empty'alt='empty_heart'>";
		echo "</div>";
		echo "</div>";
		echo "</a>";
		echo "</div>";

		echo "</div>";
	}
	?>
</div>
	<style>
		#heart_empty {
			width: 20px;
			height: 20px;
		}

	</style>


<script>
	$('.heart').hover(function() {
		$(this).find('.like').hide();
		$(this).find('.unlike').show();
	}, function() {
		$(this).find('.unlike').hide();
		$(this).find('.like').show();
	});

</script>
