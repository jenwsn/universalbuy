<?php

class Entry extends CI_Controller {

	public function index() {

		//load helper and the form validations
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->view('style_sheet');
		//Check if cookie was set. autologin when valid
		$this->load->helper('cookie');
		if(isset($_COOKIE['username']) && isset($_COOKIE['pass'])){
			$_SESSION['username'] = $_COOKIE['username'];
			$_SESSION['pass'] = $_COOKIE['pass'];
			$_SESSION['is_signed_in'] = 'yes';
		}
		$this->load->view('header');
		$this->load->view('index');
		$this->load->view('footer');
	}

}


?>

