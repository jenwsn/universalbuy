<?php

class Post extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}

	public function index()
	{
		//load url helper
		$this->load->helper('url');

		//load session
		$this->load->library('session');

		//load helper and the form validations
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->load->view('style_sheet');

		//load view
		$this->load->view('header');
		$this->load->view('post');
		$this->load->view('footer');
	}

	public function do_upload() {
		//load url helper
		$this->load->helper('url');

		//load session
		$this->load->library('session');

		//load helper and the form validations
		$this->load->library('form_validation');
		$this->load->helper('form');

		//create rules
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('description', 'description', 'required');
		$this->form_validation->set_rules('price', 'price', 'required');
		$this->form_validation->set_error_delimiters();

		//configurations
		$config['upload_path'] = './images/';
		$config['allowed_types'] = 'gif|jpeg|jpg|png';
		$config['max_size'] = '2048';
		$config['max_width'] = '2000';
		$config['max_height'] = '2000';
 		$this->load->library('upload', $config);

 		if(!$this->upload->do_upload('userfile')){
 			$image_path = 'logo.png';
		}else{
 			$data = array('upload_data' => $this->upload->data());
 			$image_path = $_FILES['userfile']['name'];
		}

		$this->load->model('Post_model');
 		$this->Post_model->post_item($image_path);
//
//		// success
//		$data = $this->input->post();
//		$info = $this->upload->data();
//
//		$image_path = $info['raw_name'].$info['file_ext'];
//		$data['path'] = $image_path;
//		$this->load->model('Post_model');
//		$array = explode(" ", implode($data));
//		$file_path = $array[2];
//		$this->Post_model->post_item($file_path);
		echo "<script type='text/javascript'>alert('Image uploaded successfully.');</script>";

		//direct to home page
		$this->load->view('header');
		$this->load->view('index');
		$this->load->view('footer');
	}
}
