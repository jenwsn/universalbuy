<?php
class Profile_model extends CI_Model {
	public function __construct(){
		parent::__construct();
	}

	public function get_info(){
		//load cookie helper
		$this->load->helper('cookie');

		//start session
		$this->load->library('session');

		//reconnect to the database
		$this->load->database();

		//indentify the current user
		$username = $_SESSION['username'];

		//prepare data array
		$data = array(
			'username' => $_SESSION['username'],
			'email'=> null,
			'phone'=> null,
		);

		$sql = "SELECT * FROM user WHERE username = ?";
		$query = $this->db->query($sql,array($username));
		$row = $query->row();

		if(isset($row)){
			//prepare data array
			$data = array(
				'username' => $_SESSION['username'],
				'email'=> $row->email,
				'phone'=> $row->phone
			);
		}
		return $data;

	}

	public function do_edit(){
		//load cookie helper
		$this->load->helper('cookie');

		//start session
		$this->load->library('session');

		//reconnect to the database
		$this->load->database();

		//indentify the current user
		$username = $_SESSION['username'];

		//prepare data array
		$data = array(
			'username' => $_SESSION['username'],
			'pass' => $_SESSION['pass'],
			'email' => $this->input->post('edit_email'),
			'phone' => $this->input->post('edit_phonenum'),
		);

		$this->db->where('username', $_SESSION['username']);
		$this->db->update('user', $data);
	}


}
