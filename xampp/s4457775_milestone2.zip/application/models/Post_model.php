<?php

class Post_model extends CI_Model{
	public function __construct() {
		parent::__construct();
	}

	public function post_item($file_path) {
		$this->load->helper('array');
		$this->load->library('session');
		$six_digit_random_number = mt_rand(100000, 999999);

		$data = array(
			'productid' => 	$six_digit_random_number,
			'name' =>$this->input->post('name'),
			'description' => $this->input->post('description'),
			'price' => $this->input->post('price'),
			'path' =>   $file_path ,
			'likes' => 0,
			'username' =>  $_SESSION['username']
		);

		$this->load->database();
		$this->db->insert('product', $data);
	}
}
