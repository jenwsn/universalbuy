<?php //if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//
//class Autocomplete_model extends CI_Model {
//
//	function getProducts($postData){
//
//		$response = array();
//
//		if(isset($postData['search']) ){
//			// Select record
//			$this->db->select('*');
//			$this->db->where("name like '%".$postData['search']."%' ");
//
//			$records = $this->db->get('product')->result();
//
//			foreach($records as $row ){
//				$response[] = array("value"=>$row->id,"label"=>$row->name);
//			}
//
//		}
//
//		return $response;
//	}
//}
