<?php

class Product_model extends CI_Model{
	public function __construct() {
		parent::__construct();
	}

	public function get_item_info($productid) {
		//reconnect to the database
		$this->load->database();

		//array helper
		$this->load->helper('array');

		//prepare data array
		$data = array(
			'productid' => $productid,
			'name'=> null,
			'description'=> null,
			'price'=> null,
			'path'=> null
		);

		$sql = "SELECT * FROM product WHERE productid = ?";
		$query = $this->db->query($sql, array($productid));
		$row = $query->row();

		if(isset($row)) {
			//assign data array
			$data = array(
				'productid' => $productid,
				'name'=> $row->name,
				'description'=> $row->description,
				'price'=> $row->price,
				'path'=> $row->path,
			);
		}

		return $data;
	}
	public function save_Item($cart_data){
		//start session
		$this->load->library('session');

		//reload database
		$this->load->database();

		//load helper array
		$this->load->helper('array');

		$this->db->insert('favorite', $cart_data);
	}

	public function remove_Item($cart_data){
		//reload database
		$this->load->database();

		//load helper array
		$this->load->helper('array');

		$this->db->delete('favorite', $cart_data);
	}

	public function get_comments($item_id){
		//reconnect to the database
		$this->load->database();

		//array helper
		$this->load->helper('array');

		$sql = "SELECT * FROM comment WHERE item = '{$item_id}'";
		$query = $this->db->query($sql);

		if($query){
			foreach ($comment_query->results_array() as $row){
				echo '<div class="panel panel-default"> <div class="panel-heading">By <b>'.$row->sender.'</b> on <i>'.$row->comment_date.'</i></div> <div class="panel-body">'.$row->comment.'</div></div>';
			}
		}

	}
}
